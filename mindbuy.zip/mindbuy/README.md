# MindBuy — Landing page

Sitio estático (HTML + CSS + JS puro, sin frameworks ni paso de build).
No necesitas Node, npm ni ningún comando de compilación: los archivos
se sirven tal cual.

## Estructura del proyecto

```
mindbuy/
├── index.html          → estructura de toda la página
├── style.css            → estilos (colores, tipografías, animaciones)
├── script.js             → interactividad (menú, scroll, videos, Instagram)
├── videos/
│   ├── video-01.mp4      ← reemplaza con tus propios videos
│   ├── video-02.mp4
│   ├── video-03.mp4
│   ├── video-04.mp4
│   └── video-05.mp4
├── images/
│   └── poster-01.jpg … poster-05.jpg   (opcional, portadas de video)
├── .gitignore
└── README.md
```

## 1. Dónde poner tus 5 videos

Copia tus archivos `.mp4` dentro de la carpeta `videos/` con estos
nombres exactos (ya están enlazados en `index.html`, no hace falta
tocar el código):

```
videos/video-01.mp4   → ¿Qué es MindBuy?
videos/video-02.mp4   → ¿Cómo funciona MindBuy?
videos/video-03.mp4   → ¿Por qué compramos cosas que no necesitamos?
videos/video-04.mp4   → 72 horas para decidir
videos/video-05.mp4   → ¿Qué significa consumir conscientemente?
```

Si quieres agregar imágenes de portada, colócalas en `images/` como
`poster-01.jpg` … `poster-05.jpg`. Son opcionales — sin ellas, la
sección igual se ve completa gracias al fondo degradado y la
etiqueta numerada de cada video.

## 2. Dónde poner tu URL de Instagram

Abre `script.js` y busca el bloque `CONFIG` al principio del archivo:

```js
var CONFIG = {
  instagramUrl: 'https://instagram.com/'   // ← cambia esto por tu URL real
};
```

Ese único valor actualiza automáticamente **todos** los enlaces de
Instagram del sitio (el ícono en la barra de navegación y el botón
"Follow MindBuy" del footer).

## 3. Subir el proyecto a GitHub

1. Crea un repositorio nuevo en GitHub (puede estar vacío, sin README).
2. En tu computador, dentro de la carpeta `mindbuy/`, ejecuta:
   ```bash
   git init
   git add .
   git commit -m "MindBuy landing page"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/TU-REPOSITORIO.git
   git push -u origin main
   ```

## 4. Desplegar en Vercel

1. Entra a [vercel.com](https://vercel.com) e inicia sesión con tu
   cuenta de GitHub.
2. Haz clic en **"Add New Project"** y selecciona el repositorio que
   acabas de subir.
3. Vercel detecta automáticamente que es un sitio estático — **no
   necesitas configurar ningún Framework Preset, Build Command ni
   Output Directory**. Deja todo en blanco/por defecto.
4. Haz clic en **Deploy**. En menos de un minuto tendrás una URL
   pública (`tu-proyecto.vercel.app`).
5. Cada vez que hagas `git push` a `main`, Vercel vuelve a desplegar
   automáticamente.

## Notas

- Los videos pueden pesar bastante — si el sitio carga lento después
  de subir tus `.mp4` reales, considera comprimirlos primero.
- Todo el diseño (paleta, tipografías Fraunces + Manrope, animaciones,
  estructura de secciones) se mantiene exactamente igual a la versión
  anterior; solo se agregaron la sección de videos y los enlaces de
  Instagram.
