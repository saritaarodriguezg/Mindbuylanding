# Carpeta /videos

Coloca aquí tus 5 archivos de video con estos nombres exactos
(el HTML ya está enlazado a ellos, no necesitas tocar el código):

- video-01.mp4  → "¿Qué es MindBuy?"
- video-02.mp4  → "¿Cómo funciona MindBuy?"
- video-03.mp4  → "¿Por qué compramos cosas que no necesitamos?"
- video-04.mp4  → "72 horas para decidir"
- video-05.mp4  → "¿Qué significa consumir conscientemente?"

Recomendaciones:
- Formato: .mp4 (códec H.264) para máxima compatibilidad en navegadores.
- Resolución sugerida: 1080p o 720p, orientación horizontal.
- Comprime los videos antes de subirlos (por ejemplo con HandBrake)
  para que el sitio cargue rápido — Vercel no impone un límite propio
  relevante para video, pero archivos muy pesados ralentizan la carga.

Este archivo (README.md) es solo una guía y no afecta el sitio;
puedes borrarlo cuando quieras.
