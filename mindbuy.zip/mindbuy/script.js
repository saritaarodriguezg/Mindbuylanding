(function(){

  "use strict";
  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var navH = 82;

  /* ============================================================
     CONFIG — cambia aquí tus datos reales
     ============================================================ */
  var CONFIG = {
    // Reemplaza esta URL por el Instagram real de MindBuy.
    // Se aplica automáticamente a TODOS los enlaces marcados
    // con el atributo data-instagram-link (navbar y footer).
    instagramUrl: 'https://instagram.com/'
  };

  document.querySelectorAll('[data-instagram-link]').forEach(function(el){
    el.href = CONFIG.instagramUrl;
  });

  /* ---------- Sticky navbar ---------- */
  var nav = document.getElementById('nav');
  function onScrollNav(){
    if(window.scrollY > 24){ nav.classList.add('is-scrolled'); }
    else{ nav.classList.remove('is-scrolled'); }
  }
  onScrollNav();
  window.addEventListener('scroll', onScrollNav, {passive:true});

  /* ---------- Mobile menu ---------- */
  var toggle = document.getElementById('navToggle');
  var mobile = document.getElementById('navMobile');
  function closeMenu(){
    mobile.classList.remove('is-open');
    document.body.classList.remove('menu-open');
    toggle.setAttribute('aria-expanded','false');
  }
  function toggleMenu(){
    var open = mobile.classList.toggle('is-open');
    document.body.classList.toggle('menu-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true':'false');
  }
  toggle.addEventListener('click', toggleMenu);
  document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeMenu(); });

  /* ---------- Smooth scroll with sticky-nav offset ---------- */
  document.querySelectorAll('[data-scroll]').forEach(function(link){
    link.addEventListener('click', function(e){
      var id = link.getAttribute('href');
      if(!id || id.charAt(0) !== '#') return;
      var target = document.querySelector(id);
      if(!target) return;
      e.preventDefault();
      closeMenu();
      var top = target.getBoundingClientRect().top + window.pageYOffset - (navH - 10);
      window.scrollTo({ top: top, behavior: reduceMotion ? 'auto' : 'smooth' });
    });
  });

  /* ---------- Scroll reveal ---------- */
  var revealEls = document.querySelectorAll('[data-reveal]');
  if('IntersectionObserver' in window){
    var io = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.18, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(function(el){ io.observe(el); });
  } else {
    revealEls.forEach(function(el){ el.classList.add('is-visible'); });
  }

  /* ---------- "Cómo funciona" scroll progress line + active step ---------- */
  var timeline = document.getElementById('howTimeline');
  var steps = document.querySelectorAll('[data-step]');
  var ticking = false;

  function updateTimeline(){
    ticking = false;
    if(!timeline) return;
    var rect = timeline.getBoundingClientRect();
    var vh = window.innerHeight;
    var total = rect.height;
    var visibleStart = vh * 0.75;
    var progressed = visibleStart - rect.top;
    var progress = total > 0 ? progressed / total : 0;
    progress = Math.max(0, Math.min(1, progress));
    timeline.style.setProperty('--progress', progress);

    var activeCount = Math.round(progress * steps.length);
    steps.forEach(function(step, i){
      step.classList.toggle('is-active', i < activeCount);
    });
  }

  function requestTick(){
    if(!ticking){
      requestAnimationFrame(updateTimeline);
      ticking = true;
    }
  }
  updateTimeline();
  window.addEventListener('scroll', requestTick, {passive:true});
  window.addEventListener('resize', requestTick);

  /* ---------- Stat count-up ---------- */
  var counters = document.querySelectorAll('[data-count]');
  function animateCounter(el){
    var target = parseInt(el.getAttribute('data-count'), 10) || 0;
    if(reduceMotion){ el.textContent = target; return; }
    var duration = 1100;
    var start = null;
    function step(ts){
      if(start === null) start = ts;
      var p = Math.min(1, (ts - start) / duration);
      var eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(eased * target);
      if(p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  if('IntersectionObserver' in window){
    var counterIO = new IntersectionObserver(function(entries){
      entries.forEach(function(entry){
        if(entry.isIntersecting){
          animateCounter(entry.target);
          counterIO.unobserve(entry.target);
        }
      });
    }, { threshold: 0.6 });
    counters.forEach(function(c){ counterIO.observe(c); });
  } else {
    counters.forEach(function(c){ c.textContent = c.getAttribute('data-count'); });
  }

  /* ---------- Video players ("Conoce MindBuy") ---------- */
  document.querySelectorAll('[data-video-frame]').forEach(function(frame){
    var video = frame.querySelector('[data-video-el]');
    var playBtn = frame.querySelector('[data-video-play]');
    if(!video || !playBtn) return;

    playBtn.addEventListener('click', function(){
      var playPromise = video.play();
      if(playPromise && typeof playPromise.catch === 'function'){
        playPromise.catch(function(){ /* no source yet — ignore */ });
      }
    });
    video.addEventListener('play', function(){ frame.classList.add('is-playing'); });
    video.addEventListener('pause', function(){ frame.classList.remove('is-playing'); });
    video.addEventListener('ended', function(){ frame.classList.remove('is-playing'); });
  });

  /* ---------- Subtle hero parallax ---------- */
  if(!reduceMotion){
    var decorEls = document.querySelectorAll('.decor');
    var pTicking = false;
    function updateParallax(){
      pTicking = false;
      var y = window.scrollY;
      decorEls.forEach(function(el, i){
        var speed = (i % 2 === 0) ? 0.06 : -0.05;
        el.style.transform = 'translateY(' + (y * speed) + 'px)';
      });
    }
    window.addEventListener('scroll', function(){
      if(!pTicking){ requestAnimationFrame(updateParallax); pTicking = true; }
    }, {passive:true});
  }
})();
