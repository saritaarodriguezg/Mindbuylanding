# Carpeta /images

Aquí van las imágenes de portada (poster) opcionales para cada video,
que se muestran antes de darle play:

- poster-01.jpg
- poster-02.jpg
- poster-03.jpg
- poster-04.jpg
- poster-05.jpg

Si no agregas estas imágenes, no pasa nada: el diseño ya tiene un
fondo degradado y una etiqueta numerada como respaldo visual, así
que la sección se ve bien igual mientras agregas tus posters.

Recomendación: imágenes en formato .jpg, orientación horizontal
(16:9 aprox.), mismo peso liviano posible (idealmente < 300 KB c/u).

Este archivo (README.md) es solo una guía y no afecta el sitio;
puedes borrarlo cuando quieras.
